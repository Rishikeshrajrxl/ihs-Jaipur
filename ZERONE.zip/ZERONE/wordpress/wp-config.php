<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'pareek2020' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ',dmqzht/!4pz=`Ij# _t1_jj4=xfgs(0?D$3urI@jI*WD$8T9epw,UK{H?;Q2*<;' );
define( 'SECURE_AUTH_KEY',  'ia4N&+]<sIP:s0ioA%MM`m*<u9T5XWt~X4G^8 Bb$7X:4sdYbhJ34n?E=D,Qhl9}' );
define( 'LOGGED_IN_KEY',    '=JF^<Yrx0s3PxbhaN4-pBZ>TFT~vew)}%;Jv* P6s#fEsh0-C:]&]*.},Hr(H/F.' );
define( 'NONCE_KEY',        'L^6.O~GYC*#/Q45AfK_a?d2NgI$_%S.T<)8>Fj}WG.-W[{:PVpHK-6Bh}r{$0D+2' );
define( 'AUTH_SALT',        '.(2e#Y9q<+?k*ki,dW{}?M~<1?(_n=8q4UD/VpDZ.V[37`hDv0+YZ]t50MLLZZXd' );
define( 'SECURE_AUTH_SALT', '#&Sx7T.;fvXxVe-KK}_.MqhP0S9YEVS^HI9@>6inczK|2e~34Z>o|mQ64VjWe#wi' );
define( 'LOGGED_IN_SALT',   'ozP::dX@(Dhu45qWo(d#mJWXc@/js0|/!P?@(};og`@1>joh&R*Jcx0q6#@jNJwR' );
define( 'NONCE_SALT',       ' {<-hZ@0{ ${omvH[b8P2@[[YaywUA7`,jI]R(ZCg3os* j{azyVdR.!>;^v|8go' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
